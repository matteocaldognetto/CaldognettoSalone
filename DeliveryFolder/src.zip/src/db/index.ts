import schema from "./schema";

export type { DbSchema } from "./schema";
export { schema };

export * from "./drizzle";
